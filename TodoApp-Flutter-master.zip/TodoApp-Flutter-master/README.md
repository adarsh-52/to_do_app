# Todo App UI

A sample UI for todo app developed in flutter

## Demo

<p>
  <img src="images/todo-app-screenshot.jpg" width="350">
</p>

